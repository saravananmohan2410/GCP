---
title: Create GCP Cloud Account
description: Learn to create GCP Cloud Account
---

## Step-01: Introduction
- Create GCP Cloud Account

## Step-02: Create a Google Account
- We should have a google account (gmail account) before creating GCP cloud Account
- Create one Google Account if not having one.

## Step-03: Create GCP Account
- Go to https://cloud.google.com
- Follow presentation slides to create the GCP Account

## Step-04: Create Budget Alerts
- Go to Billing and Create Budget Alerts
